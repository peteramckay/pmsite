# Interactive Resume

Included here is an interactive resume for Peter A. McKay, built using Bootstrap and jQuery for the Knight Foundation. It can be viewed offline by opening the resume.html file, or via the web at http://bit.ly/2EjWVXZ

I recommend viewing this little web app on a desktop computer. It should be fully responsive for smaller screens as well, but I think the desktop experience will be optimal, as that's how I've primarily tested it in development.

This software is free to use under MIT license.

Cheers,

Peter A. McKay      
peter@indizr.com        
510-332-6764        

